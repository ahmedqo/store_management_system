<?php

require __DIR__ . '/quotation.php';
require __DIR__ . '/category.php';
require __DIR__ . '/product.php';
require __DIR__ . '/profile.php';
require __DIR__ . '/request.php';
require __DIR__ . '/brand.php';
require __DIR__ . '/guest.php';
require __DIR__ . '/user.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/core.php';
