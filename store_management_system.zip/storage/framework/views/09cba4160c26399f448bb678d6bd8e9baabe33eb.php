<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body class="flex flex-col flex-wrap lg:flex-row bg-gray-100 !overflow-hidden !h-screen">
    <section id="overlay"
        class="bg-x-prime bg-opacity-80 backdrop-blur-lg fixed inset-0 z-[100] flex items-center justify-center">
        <img title="logo-image" alt="logo-image" src="<?php echo e(asset('img/logo.svg')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"
            class="block w-32 animate-bounce duration-150" />
    </section>
    <?php echo $__env->make('shared.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="flex flex-col w-full lg:w-[calc(100%-240px)] lg:flex-1">
        <?php echo $__env->make('shared.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="w-full container mx-auto p-4">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </main>
    <script src="<?php echo e(asset('js/x.elements.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php if(Session::has('message')): ?>
        <script>
            const data = <?php echo json_encode(Session::all()); ?>;
            x.Toaster(data.message, data.type);
        </script>
    <?php endif; ?>
    <script>
        x.DatePicker.opts.DataText.Days = ["<?php echo e(ucwords(__('sunday'))); ?>", "<?php echo e(ucwords(__('monday'))); ?>",
            "<?php echo e(ucwords(__('tuesday'))); ?>",
            "<?php echo e(ucwords(__('wednesday'))); ?>", "<?php echo e(ucwords(__('thursday'))); ?>",
            "<?php echo e(ucwords(__('friday'))); ?>",
            "<?php echo e(ucwords(__('saturday'))); ?>"
        ];
        x.DatePicker.opts.DataText.Months = ["<?php echo e(ucwords(__('january'))); ?>",
            "<?php echo e(ucwords(__('february'))); ?>",
            "<?php echo e(ucwords(__('march'))); ?>", "<?php echo e(ucwords(__('april'))); ?>",
            "<?php echo e(ucwords(__('may'))); ?>",
            "<?php echo e(ucwords(__('june'))); ?>", "<?php echo e(ucwords(__('july'))); ?>",
            "<?php echo e(ucwords(__('august'))); ?>",
            "<?php echo e(ucwords(__('september'))); ?>", "<?php echo e(ucwords(__('october'))); ?>",
            "<?php echo e(ucwords(__('november'))); ?>",
            "<?php echo e(ucwords(__('december'))); ?>"
        ];
        x.DataTable.opts.DataText.Search = "<?php echo e(ucwords(__('Search'))); ?>...";
        x.DataTable.opts.DataText.Filter = "<?php echo e(ucwords(__('Filter'))); ?>";
        x.DataTable.opts.DataText.Empty = "<?php echo e(__('No data found')); ?>";
        x.Select.opts.DataText.Search = "<?php echo e(ucwords(__('Search'))); ?>";
        x.DatePicker.opts.FullDay = <?php echo e(Core::lang('ar') ? 'true' : '3'); ?>;
        x.Print.opts.css = [
            "<link rel='stylesheet' href='<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>' />",
            "<link rel='stylesheet' href='<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>' />"
        ];
        x.Print.opts.dir = "<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>";
        x.Print.opts.lang = "<?php echo e(app()->getLocale()); ?>";
        x.Print.opts.margin = "10mm 10mm 10mm 10mm";

        x.Toggle();
        x.Toggle.disable({
            xs: [{
                selector: "#settings",
                class: "opacity-0",
            }, {
                selector: "#languages",
                class: "opacity-0",
            }, {
                selector: "#menu",
                class: "-left-full",
            }],
            lg: [{
                selector: "#menu",
                class: "left-0",
            }, ],
        });
        ["DOMContentLoaded", "resize"].forEach(event => {
            window.addEventListener(event, () => {
                if (event === "DOMContentLoaded") {
                    document.querySelector("#overlay").remove();
                    document.body.classList.remove("!overflow-hidden", "!h-screen");
                }
                document.documentElement.style.setProperty('--vh', `${window.innerHeight}px`);
            });
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH P:\php\store_management_system\resources\views/shared/admin/base.blade.php ENDPATH**/ ?>