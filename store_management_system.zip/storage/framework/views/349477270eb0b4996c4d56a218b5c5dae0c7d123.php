<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <title><?php echo e(ucwords($data->name)); ?></title>
</head>

<body>
    <header>
        <?php echo $__env->make('shared.guest.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <main class="w-full container mx-auto">
        <section class="w-full flex flex-col lg:flex-row lg:flex-wrap gap-4 p-4">
            <?php echo $__env->make('shared.guest.list', [
                'items' => [[__('Home'), '#'], [ucwords($data->Category->name), '#'], [ucwords($data->name), '#']],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="w-full lg:w-7/12">
                <div class="w-full sticky top-4">
                    <div id="slide" class="w-full aspect-video rounded-md bg-gray-100 p-2">
                        <ul class="w-full h-full">
                            <?php $__currentLoopData = $data->Files->reverse();
                            $__env->addLoop($__currentLoopData);
                            foreach ($__currentLoopData as $file) : $__env->incrementLoopIndices();
                                $loop = $__env->getLastLoop(); ?>
                                <li class="w-full h-full flex items-center justify-center">
                                    <img src="<?php echo e(Core::files(Core::PRODUCT)->get($file->name)); ?>" alt="<?php echo e($data->slug); ?>_image_<?php echo e($loop->index + 1); ?>" class="block w-full h-full object-contain" />
                                </li>
                            <?php endforeach;
                            $__env->popLoop();
                            $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div dir="ltr" class="flex w-full p-2 justify-between items-center absolute top-1/2 -translate-y-1/2 left-0 right-0 pointer-events-none">
                        <button id="prev" class="pointer-events-auto flex rounded-full w-8 h-8 items-center justify-center bg-x-prime text-gray-50 hover:text-x-black focus:text-x-black hover:bg-x-acent focus:bg-x-acent outline-none">
                            <svg class="pointer-events-none w-6 h-6" fill="currentColor" viewBox="0 96 960 960">
                                <path d="M528 805 331 607q-7-6-10.5-14t-3.5-18q0-9 3.5-17.5T331 543l198-199q13-12 32-12t33 12q13 13 12.5 33T593 410L428 575l166 166q13 13 13 32t-13 32q-14 13-33.5 13T528 805Z" />
                            </svg>
                        </button>
                        <button id="next" class="pointer-events-auto flex rounded-full w-8 h-8 items-center justify-center bg-x-prime text-gray-50 hover:text-x-black focus:text-x-black hover:bg-x-acent focus:bg-x-acent outline-none">
                            <svg class="pointer-events-none w-6 h-6" fill="currentColor" viewBox="0 96 960 960">
                                <path d="M344 805q-14-15-14-33.5t14-31.5l164-165-165-166q-14-12-13.5-32t14.5-33q13-14 31.5-13.5T407 344l199 199q6 6 10 14.5t4 17.5q0 10-4 18t-10 14L408 805q-13 13-32 12.5T344 805Z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <div class="w-full lg:flex-[1] flex flex-col gap-5 lg:gap-6">
                <div class="flex flex-col">
                    <h1 class="font-x-core text-x-black text-2xl lg:text-4xl"><?php echo e(ucwords($data->name)); ?></h1>
                    <?php if ($data->reference) : ?>
                        <h3 class="font-x-core text-gray-400 text-md lg:text-lg"><?php echo e(__('Ref')); ?>:
                            <?php echo e(strtoupper($data->reference)); ?>

                        </h3>
                    <?php endif; ?>
                </div>
                <div class="flex flex-col gap-3">
                    <p class="text-base text-gray-500">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nostrum earum expedita, iste natus
                        consequuntur totam, itaque tenetur dolore nulla cum omnis minima ipsum quia voluptate! Dolorum
                        maxime fugit perferendis omnis?
                    </p>
                    <div class="w-max flex flex-col gap-2">
                        <h6 class="text-sm font-bold"><?php echo e(__('Brand')); ?>:</h6>
                        <a href="#" class="flex gap-2 items-center">
                            <img src="<?php echo e(Core::files(Core::BRAND)->get($data->Brand->file)); ?>" class="block max-h-[3rem] max-w-[6rem] object-contain" alt="<?php echo e($data->Brand->name); ?>_image">
                            <h6 class="text-md font-x-core"><?php echo e(ucwords($data->Brand->name)); ?></h6>
                        </a>
                    </div>
                </div>
                <form class="w-full flex flex-col mt-auto gap-5 lg:gap-6">
                    <div id="counter" class="flex flex-wrap w-max gap-1 items-center">
                        <button counter="-" class="w-6 h-6 flex items-center justify-center rounded-full border-2 border-x-prime text-x-prime text-lg font-black outline-none hover:border-x-acent hover:text-x-acent focus:border-x-acent focus:text-x-acent">
                            <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
                                <path d="M225-434q-20.75 0-33.375-13.36Q179-460.719 179-479.86q0-20.14 12.625-32.64T225-525h511q19.775 0 32.888 12.675Q782-499.649 782-479.509q0 19.141-13.112 32.325Q755.775-434 736-434H225Z" />
                            </svg>
                        </button>
                        <input counter="x" type="number" name="qte" value="1" class="w-20 text-center bg-transparent text-x-black font-black p-1 text-md rounded-md focus-within:outline-x-prime focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2" />
                        <button counter="+" class="w-6 h-6 flex items-center justify-center rounded-full border-2 border-x-prime text-x-prime text-lg font-black outline-none hover:border-x-acent hover:text-x-acent focus:border-x-acent focus:text-x-acent">
                            <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
                                <path d="M479.825-185q-18.45 0-31.637-12.625Q435-210.25 435-231v-203H230q-18.375 0-31.688-13.56Q185-461.119 185-479.86q0-20.14 13.312-32.64Q211.625-525 230-525h205v-205q0-19.775 13.358-32.388Q461.716-775 480.158-775t32.142 12.612Q526-749.775 526-730v205h204q18.8 0 32.4 12.675 13.6 12.676 13.6 32.316 0 19.641-13.6 32.825Q748.8-434 730-434H526v203q0 20.75-13.65 33.375Q498.699-185 479.825-185Z" />
                            </svg>
                        </button>
                    </div>
                    <button class="w-full rounded-md px-4 py-2 text-xl lg:text-2xl font-x-core text-gray-50 bg-x-prime hover:text-x-black focus:text-x-black hover:bg-x-acent focus:bg-x-acent outline-none">
                        <?php echo e(__('Add To Cart')); ?>

                    </button>
                </form>
            </div>
            <div class="w-full flex flex-col gap-3">
                <h6 class="text-md font-bold"><?php echo e(__('Description')); ?>:</h6>
                <div class="x-revert">
                    <?php echo $data->description; ?>

                </div>
            </div>
        </section>
        <section class="mb-32 w-1/5 p-4 rounded-md bg-slate-50">
            <ul class="x-category relative">
                <?php $__currentLoopData = $categories;
                $__env->addLoop($__currentLoopData);
                foreach ($__currentLoopData as $base) : $__env->incrementLoopIndices();
                    $loop = $__env->getLastLoop(); ?>
                    <?php if (!$base->Category) : ?>
                        <?php echo $__env->make('shared.guest.partial', [
                            'base' => $base,
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                <?php endforeach;
                $__env->popLoop();
                $loop = $__env->getLastLoop(); ?>
            </ul>
        </section>
    </main>
    <script src="<?php echo e(asset('js/x.elements.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php if (Session::has('message')) : ?>
        <script>
            const data = <?php echo json_encode(Session::all()); ?>;
            x.Toaster(data.message, data.type);
        </script>
    <?php endif; ?>
    <script>
        x.Toggle();
        x.Toggle.disable({
            xs: [{
                selector: "#language",
                class: "opacity-0",
            }, {
                selector: "#navigation",
                class: "opacity-0",
            }, ],
            lg: [{
                selector: "#navigation",
                class: "0000",
            }, ]
        });
        Counter("#counter");
        Slider({
            wrap: "#slide",
            next: "#next",
            prev: "#prev",
        }, {
            flip: <?php echo e(Core::lang('ar') ? 'true' : 'false'); ?>,
            auto: true,
            time: 5000,
            touch: true,
            infinite: true,
        });


        const form = document.querySelector("#form"),
            field = form.querySelector("#search");
        form.addEventListener("submit", e => {
            e.preventDefault();
            form.action = form.action.replace(/%SLUG%/, field.value);
            form.submit();
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/product/single.blade.php ENDPATH**/ ?>