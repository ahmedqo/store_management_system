<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <section id="overlay"
        class="bg-x-prime bg-opacity-80 backdrop-blur-lg fixed inset-0 z-[100] flex items-center justify-center">
        <img title="logo-image" alt="logo-image" src="<?php echo e(asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"
            class="block w-32 animate-bounce duration-150" />
    </section>
    <header>
        <?php echo $__env->make('shared.guest.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('header'); ?>
    </header>
    <main class="w-full container mx-auto">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="<?php echo e(asset('js/x.elements.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php if(Session::has('message')): ?>
        <script>
            const data = <?php echo json_encode(Session::all()); ?>;
            x.Toaster(data.message, data.type);
        </script>
    <?php endif; ?>
    <script>
        x.Toggle();
        x.Toggle.disable({
            xs: [{
                selector: "#languages",
                class: "opacity-0",
            }, {
                selector: "#navigation",
                class: "opacity-0",
            }, ],
            lg: [{
                selector: "#navigation",
                class: "0000",
            }, ]
        });
        window.addEventListener("DOMContentLoaded", () => {
            document.querySelector("#overlay").remove();
            document.body.classList.remove("!overflow-hidden", "!h-screen");
        });
        const form = document.querySelector("#form"),
            field = form.querySelector("#search");
        form.addEventListener("submit", e => {
            e.preventDefault();
            form.action = form.action.replace(/%SLUG%/, field.value);
            form.submit();
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/shared/guest/base.blade.php ENDPATH**/ ?>