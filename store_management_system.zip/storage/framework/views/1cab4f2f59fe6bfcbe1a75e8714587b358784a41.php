
<?php $__env->startSection('title', __('Dashboard')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col gap-4">
        <div class="w-full flex items-center justify-between gap-2">
            <h1 class="font-x-core text-2xl"><?php echo e(__('Schedule')); ?></h1>
        </div>
        <div id="calendar" class="w-full"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/core/index.blade.php ENDPATH**/ ?>