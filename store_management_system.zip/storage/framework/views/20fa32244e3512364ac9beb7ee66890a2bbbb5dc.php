
<?php $__env->startSection('title', __('Home')); ?>

<?php $__env->startSection('header'); ?>
    <div
        class="w-full min-h-[8rem] aspect-[12/4] flex items-center justify-center text-x-white font-x-core text-2xl lg:text-6xl p-4 bg-cover bg-no-repeat relative z-[0] bg-center before:content-[''] before:inset-0 before:bg-x-black-blur before:absolute before:z-[-1]">
        <?php echo e(__('Home')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full flex flex-col gap-4 lg:gap-6 p-4 lg:my-2">
        <?php if($brands->count()): ?>
            <section class="w-full">
                
                <div class="w-[calc(100%+2rem)] -ms-4">
                    <div id="slide" class="w-full">
                        <ul class="w-full h-full">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="p-3">
                                    <a href="<?php echo e(route('views.guest.products', [
                                        'brand' => $row->slug,
                                    ])); ?>"
                                        class="relative overflow-hidden aspect-square rounded-full shadow-x-core bg-x-white p-4 flex items-center justify-center transition-transform hover:-translate-y-2 focus-within:-translate-y-2">
                                        <img src="<?php echo e(Core::files(Core::BRAND)->get($row->file)); ?>"
                                            alt="<?php echo e($row->slug); ?>_image"
                                            class="block max-w-full max-h-full object-contain" />
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if($categories->count() > 2): ?>
            
            <section class="w-full grid gap-4 lg:gap-6 <?php echo e($class['parent']); ?>">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('views.guest.products', [
                        'category' => $row->slug,
                    ])); ?>"
                        class="relative w-full h-full group overflow-hidden rounded-x-core shadow-x-core bg-x-white flex items-center justify-center <?php echo e($class['children'][$loop->index]); ?>">
                        <img src="<?php echo e(Core::files(Core::CATEGORY)->get($row->file)); ?>" alt="<?php echo e($row->slug); ?>_image"
                            class="block w-full h-full object-cover scale-110 transition-transform group-hover:scale-150 group-focus:scale-150" />
                        <div
                            class="bg-x-black-blur text-x-white opacity-0 group-hover:opacity-100 group-focus:opacity-100 pointer-events-none transition-opacity w-full h-full absolute inset-0 flex items-center justify-center p-4 backdrop-blur-sm">
                            <h4 class="text-2xl lg:text-3xl font-x-core text-center">
                                <?php echo e(ucwords($row->name)); ?>

                            </h4>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        <?php if($brands->count()): ?>
            const slider = document.querySelector("#slide").parentElement;
            Slider({
                wrap: "#slide",
            }, {
                flip: <?php echo e(Core::lang('ar') ? 'true' : 'false'); ?>,
                time: 5000,
            }).resize(($) => {
                const size = slider.clientWidth / 10;
                $.update({
                    <?php echo e($brands->count() < 10 ? 'infinite: false, touch: false, auto: false, cols: ' . $brands->count() . ', size: size,' : 'infinite: true, touch: true, auto: true, cols: 10, size: false,'); ?>

                })
            }, ($) => {
                const size = slider.clientWidth / 4;
                $.update({
                    <?php echo e($brands->count() < 4 ? 'infinite: false, touch: false, auto: false, cols: ' . $brands->count() . ', size: size,' : 'infinite: true, touch: true, auto: true, cols: 4, size: false,'); ?>

                })
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.guest.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/guest/home.blade.php ENDPATH**/ ?>