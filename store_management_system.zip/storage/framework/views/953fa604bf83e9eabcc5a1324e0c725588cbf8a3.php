<li>
    <a href="<?php echo e(route('views.guest.category', $base->slug)); ?>"
        class="flex items-center gap-2 outline-none rounded-md text-x-black hover:px-2 hover:py-1 focus-within:px-2 focus-within:py-1 hover:bg-gray-300 hover:bg-opacity-40 focus-within:bg-gray-300 focus-within:bg-opacity-40">
        <?php if($base->Category): ?>
            <span class="block w-1.5 h-1.5 bg-x-black rounded-md"></span>
        <?php endif; ?>
        <span class="text-lg font-x-core"><?php echo e(ucwords($base->name)); ?></span>
    </a>
    <?php if($base->Categories->count()): ?>
        <ul
            class="x-category relative ps-4 before:content-[''] before:absolute before:top-1/2 before:-translate-y-1/2 before:hidden before:w-[2px] before:bg-x-black before:h-[calc(80%)] before:left-[1.13rem] rtl:before:left-auto rtl:before:right-[1.13rem]">
            <?php $__currentLoopData = $base->Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('shared.guest.partial', [
                    'base' => $category,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/shared/guest/partial.blade.php ENDPATH**/ ?>