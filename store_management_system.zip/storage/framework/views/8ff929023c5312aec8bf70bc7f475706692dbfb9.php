
<?php $__env->startSection('title', ucwords(__('Request Summary')) . ' #' . $data->id); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col gap-4">
        <div class="w-full flex items-center justify-between gap-2">
            <h1 class="font-x-core text-2xl"><?php echo e(ucwords(__('Request Summary'))); ?> #<?php echo e($data->id); ?></h1>
            <div
                class="lg:w-max fixed bottom-0 left-0 right-0 lg:relative lg:bottom-auto lg:left-auto lg:right-auto z-[5] lg:z-0 pointer-events-none">
                <div class="container mx-auto lg:w-max p-4 lg:p-0">
                    <div
                        class="w-max flex gap-[2px] flex-col lg:flex-row ms-auto pointer-events-auto rounded-x-core overflow-hidden">
                        <a href="<?php echo e(route('views.quotations.store', ['target' => $data->id])); ?>"
                            class="flex gap-2 items-center justify-center font-x-core text-sm rounded-sm bg-slate-400 text-x-white relative p-2 lg:px-4 h-[42px] aspect-square lg:aspect-auto outline-none hover:!text-x-black hover:bg-slate-300 focus-within:!text-x-black focus-within:bg-slate-300">
                            <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
                                <path
                                    d="M278-150v-440q0-38.063 27-65.532Q332-683 369-683h441q37.75 0 64.875 27.125T902-591v287q0 19.444-7.5 36.222Q887-251 874-238L722-86q-13 13-29.778 20T657-59H369q-37.75 0-64.375-26.625T278-150ZM60-717q-7-37 15-68.5t59-37.5l435-77q37-6 68.5 15.5T675-826l14 83H370q-62 0-107 44.75T218-591v383q-30-2-53-22t-28-53L60-717Zm484 392v77q0 20.75 13.175 33.375 13.176 12.625 33 12.625Q610-202 622.5-214.625 635-227.25 635-248v-77h78q19.75 0 32.375-12.675Q758-350.351 758-371.175 758-390 745.375-403T713-416h-78v-78q0-18.75-12.675-31.875Q609.649-539 589.825-539 570-539 557-525.875 544-512.75 544-494v78h-77q-19.75 0-32.875 13.175-13.125 13.176-13.125 32Q421-350 434.125-337.5 447.25-325 467-325h77Z" />
                            </svg>
                            <span class="hidden lg:block"><?php echo e(__('Quote')); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="toremove bg-x-white rounded-x-core shadow-x-core p-4">
            <div class="w-full grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-4">
                <div class="flex flex-col gap-px lg:col-span-3">
                    <label class="text-x-black font-x-core text-sm"><?php echo e(__('Created at')); ?></label>
                    <div class="w-full bg-x-light text-x-black border-x-shade p-2 text-base border rounded-md">
                        <?php echo e($data->created_at->diffForHumans()); ?></div>
                </div>
                <div class="flex flex-col gap-px">
                    <label class="text-x-black font-x-core text-sm"><?php echo e(__('Name')); ?></label>
                    <div class="w-full bg-x-light text-x-black border-x-shade p-2 text-base border rounded-md">
                        <?php echo e(ucwords($data->name)); ?>

                    </div>
                </div>
                <div class="flex flex-col gap-px">
                    <label class="text-x-black font-x-core text-sm"><?php echo e(__('Email')); ?></label>
                    <div class="w-full bg-x-light text-x-black border-x-shade p-2 text-base border rounded-md">
                        <?php echo e($data->email); ?>

                    </div>
                </div>
                <div class="flex flex-col gap-px">
                    <label class="text-x-black font-x-core text-sm"><?php echo e(__('Phone')); ?></label>
                    <div class="w-full bg-x-light text-x-black border-x-shade p-2 text-base border rounded-md">
                        <?php echo e($data->phone); ?>

                    </div>
                </div>
                <div class="flex flex-col gap-px lg:col-span-3">
                    <label class="text-x-black font-x-core text-sm"><?php echo e(__('Products')); ?></label>
                    <table default x-table>
                        <thead>
                            <tr>
                                <td>
                                    <div class="w-max mx-auto">#</div>
                                </td>
                                <td class="w-20">
                                    <div class="w-max mx-auto"><?php echo e(__('Image')); ?></div>
                                </td>
                                <td><?php echo e(__('Name')); ?></td>
                                <td>
                                    <div class="w-max mx-auto"><?php echo e(__('Quantity')); ?></div>
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="w-max mx-auto font-x-core text-sm"><?php echo e($loop->index + 1); ?></div>
                                    </td>
                                    <td class="w-20">
                                        <img alt="<?php echo e($item->Product->name . ' image'); ?>"
                                            src="<?php echo e(Core::files(Core::PRODUCT)->get($item->Product->Files->first()->name)); ?>"
                                            class="block mx-auto rounded-md bg-x-white border border-x-black-blur w-20 aspect-square object-contain" />
                                    </td>
                                    <td><?php echo e($item->Product->name); ?></td>
                                    <td>
                                        <div class="w-max mx-auto"><?php echo e($item->quantity); ?></div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php if($data->message): ?>
                    <div class="flex flex-col gap-px lg:col-span-3">
                        <label class="text-x-black font-x-core text-sm"><?php echo e(__('Message')); ?></label>
                        <div class="w-full bg-x-light text-x-black border-x-shade p-2 text-base border rounded-md">
                            <?php echo e($data->message); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        x.DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\store_management_system\resources\views/request/scene.blade.php ENDPATH**/ ?>