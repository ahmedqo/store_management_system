<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
    <title><?php echo e(__('Quotation Summary') . ' #' . $data->reference); ?></title>
</head>

<body>
    <main id="page" class="hidden w-full container mx-auto">
        <header class="fixed top-0 left-0 right-0 w-full flex flex-wrap gap-4 items-end">
            <div class="flex-1 flex flex-col gap-2">
                <img alt="logo-image" src="<?php echo e(asset('img/logo.svg')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"
                    class="block w-28 flex-1 object-contain object-center" />
                <div class="w-[calc(100%-5px)] h-4 bg-x-prime skew-x-[-20deg] ms-[5px]"></div>
            </div>
            <div class="w-max flex flex-col gap-2">
                <div class="w-max flex flex-col mx-4">
                    <h1 class="text-x-black">
                        <span class="font-x-core"><?php echo e(ucwords(__('Ref No'))); ?></span>:
                        <?php echo e(strtoupper($data->reference)); ?>

                    </h1>
                    <h1 class="text-x-black">
                        <span class="font-x-core"><?php echo e(__('Date')); ?></span>:
                        <?php echo e($data->created_at); ?>

                    </h1>
                    <h1 class="text-x-black">
                        <span class="font-x-core"><?php echo e(ucwords(__('Customer name'))); ?></span>:
                        <?php echo e(ucwords($data->name)); ?>

                    </h1>
                </div>
                <div class="flex gap-2 skew-x-[-20deg]">
                    <div class="w-[2rem] h-10 bg-x-acent"></div>
                    <div class="flex-1 h-10 bg-x-acent me-[8px]"></div>
                </div>
            </div>
        </header>
        <div class="flex flex-col my-4">
            <h1 class="text-x-black font-x-core text-2xl mb-4 leading-[1] text-center">
                <?php echo e(__('Quotation') . ' #' . strtoupper($data->reference)); ?>

            </h1>
            <div class="border-x-shade border w-full rounded-sm">
                <table class="w-full">
                    <thead>
                        <tr>
                            <td class="text-x-black text-sm font-x-core p-2 ps-4">
                                <div class="w-max mx-auto">#</div>
                            </td>
                            <td class="text-x-black text-sm font-x-core p-2"><?php echo e(__('Name')); ?></td>
                            <td class="text-x-black text-sm font-x-core p-2 w-[100px] text-center"><?php echo e(__('Unit')); ?>

                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 w-[100px] text-center"><?php echo e(__('Quantity')); ?>

                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 w-[100px] text-center">
                                <?php echo e(ucwords(__('Unit price'))); ?><br />(<?php echo e($data->currency); ?>)
                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 pe-4 w-[100px] text-center">
                                <?php echo e(ucwords(__('Lot price'))); ?><br />(<?php echo e($data->currency); ?>)
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-x-shade border-t">
                                <td class="text-x-black text-sm font-x-core p-2 ps-4">
                                    <div class="w-max mx-auto font-x-core text-sm"><?php echo e($loop->index + 1); ?></div>
                                </td>
                                <td class="text-x-black text-sm font-x-core p-2 ps-4"><?php echo e($item->Product->details); ?>

                                </td>
                                <td class="text-x-black text-sm font-x-core p-2 text-center w-[100px]">
                                    <?php echo e($item->unit); ?>

                                </td>
                                <td class="text-x-black text-sm font-x-core p-2 text-center w-[100px]">
                                    <?php echo e($item->quantity); ?>

                                </td>
                                <td class="text-x-black text-sm font-x-core p-2 text-center w-[100px]">
                                    <?php echo e(number_format($item->price)); ?></td>
                                <td class="text-x-black text-sm p-2 text-center w-[100px] font-x-core">
                                    <?php echo e(number_format($item->price * $item->quantity)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-x-shade border-t">
                            <td colspan="5" class="text-x-black text-sm font-x-core p-2 text-center">
                                <?php echo e(ucwords(__('Lot price'))); ?> (<?php echo e($data->currency); ?>)
                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 pe-4 text-center w-[100px]">
                                <?php echo e(number_format($data->Total())); ?>

                            </td>
                        </tr>
                        <tr class="border-x-shade border-t">
                            <td colspan="5" class="text-x-black text-sm font-x-core p-2 text-center">
                                <?php echo e(__('Charges')); ?> (<?php echo e($data->currency); ?>)
                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 pe-4 text-center w-[100px]">
                                <?php echo e(number_format($data->Charge())); ?>

                            </td>
                        </tr>
                        <tr class="border-x-shade border-t">
                            <td colspan="5" class="text-x-black text-sm font-x-core p-2 text-center">
                                <?php echo e(ucwords(__('Total amount'))); ?> (<?php echo e($data->currency); ?>)
                            </td>
                            <td class="text-x-black text-sm font-x-core p-2 pe-4 text-center w-[100px]">
                                <?php echo e(number_format($data->Total() + $data->Charge())); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <?php if($data->note): ?>
                <p class="text-x-black font-x-core mt-4">
                    <?php echo e($data->note); ?>

                </p>
            <?php endif; ?>
        </div>
        <footer class="fixed bottom-0 left-0 right-0 w-full flex flex-wrap gap-4 items-stretch">
            <div class="flex-1 flex flex-wrap gap-2 skew-x-[-20deg]">
                <div class="flex-1 h-full bg-x-acent ms-[8px]"></div>
                <div class="w-[2rem] h-full bg-x-acent"></div>
            </div>
            <div class="w-8/12 flex flex-col gap-2">
                <div class="w-[calc(100%-5px)] h-4 bg-x-prime skew-x-[-20deg] me-[5px]"></div>
                <div class="flex gap-4 justify-around">
                    <h1 class="text-x-black font-x-core">www.store.com</h1>
                    <h1 class="text-x-black font-x-core">store@test.com</h1>
                    <h1 class="text-x-black font-x-core">+XXX-XXXX-XXXX</h1>
                </div>
            </div>
        </footer>
    </main>
    <script src="<?php echo e(asset('js/x.elements.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php if(Session::has('message')): ?>
        <script>
            const data = <?php echo json_encode(Session::all()); ?>;
            x.Toaster(data.message, data.type);
            if (data.clean) {
                localStorage.removeItem("<?php echo e(env('APP_CART')); ?>");
            }
        </script>
    <?php endif; ?>
    <script>
        x.Print.opts = {
            ...x.Print.opts,
            css: [
                "<link rel='stylesheet' href='<?php echo e(asset('css/index.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>' />",
                "<link rel='stylesheet' href='<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>' />"
            ],
            dir: "<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>",
            lang: "<?php echo e(app()->getLocale()); ?>",
            margin: "10mm 10mm 10mm 10mm",
            size: {
                head: "150px",
                foot: "70px",
                page: "A4"
            }
        }
        document.addEventListener("DOMContentLoaded", () => {
            x.Print("#page", {
                exec: true
            });
        });
    </script>
</body>

</html>
<?php /**PATH P:\php\store_management_system\resources\views/guest/quote.blade.php ENDPATH**/ ?>