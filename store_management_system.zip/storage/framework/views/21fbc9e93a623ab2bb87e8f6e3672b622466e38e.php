<?php $__env->startSection('title', __('Forgot Password')); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('actions.blank.index')); ?>" method="POST" class="w-full gap-4 flex flex-col">
    <?php echo csrf_field(); ?>
    <p class="font-x-core text-sm text-x-black">
        <?php echo e(__('Did you forget your password? No problem. Just tell us your email address, and we will send you a link that will allow you to choose a new password.')); ?>

    </p>
    <div class="flex flex-col gap-px">
        <label for="email" class="text-x-black font-x-core text-sm"><?php echo e(__('Email')); ?></label>
        <input id="email" type="email" name="email" placeholder="<?php echo e(__('Email')); ?>" class="bg-x-light text-x-black border-x-shade focus-within:outline-x-prime p-2 text-base border rounded-md focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2" />
    </div>
    <button class="w-full lg:w-max flex justify-center gap-2 items-center font-x-core text-sm rounded-md bg-x-prime text-x-white relative h-[42px] px-4 outline-none hover:!text-x-black hover:bg-x-acent focus-within:!text-x-black focus-within:bg-x-acent ms-auto">
        <svg class="block w-5 h-5 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
            <path d="M382-396 100-505q-15-5-22-17.5T71-548q0-14 7-25t22-18l678-260q13-5 26-2t22 12q10 11 13.5 23.5T838-791L577-113q-6 16-17 22.5T535-84q-14 0-26.5-7T491-114L382-396Z" />
        </svg>
        <span><?php echo e(__('Send')); ?></span>
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.auth.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/auth/blank.blade.php ENDPATH**/ ?>