<?php
$items = isset($items) ? $items : false;
?>
<?php if ($items) : ?>
    <nav class="w-full overflow-auto lg:overflow-unset -mb-2">
        <ul class="flex gap-2 text-x-black text-md font-medium w-max">
            <?php $__currentLoopData = $items;
            $__env->addLoop($__currentLoopData);
            foreach ($__currentLoopData as $item) : $__env->incrementLoopIndices();
                $loop = $__env->getLastLoop(); ?>
                <li>
                    <a <?php echo e(count($item) > 1 ? 'href=' . $item[1] : ''); ?>><?php echo e($item[0]); ?></a>
                </li>
                <?php if ($loop->index < count($items) - 1) : ?>
                    <li>-</li>
                <?php endif; ?>
            <?php endforeach;
            $__env->popLoop();
            $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\ahmedqo\Desktop\store_app\resources\views/shared/guest/list.blade.php ENDPATH**/ ?>