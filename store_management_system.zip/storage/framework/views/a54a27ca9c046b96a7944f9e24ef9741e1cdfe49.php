<li>
    <div x-toggle targets="#category_<?php echo e($base->id); ?>" properties="hidden"
        class="flex items-center justify-between gap-2 text-x-black rounded-md hover:px-2 hover:py-1 focus-within:px-2 focus-within:py-1 hover:bg-x-black-blur focus-within:bg-x-black-blur">
        <a class="text-lg font-x-core <?php echo e($base->Categories->count() ? 'w-max' : 'w-full'); ?>"
            href="<?php echo e(route('views.guest.products', [
                'category' => $base->slug,
            ])); ?>"><?php echo e(ucwords($base->name)); ?></a>
        <?php if($base->Categories->count()): ?>
            <span
                class="bg-x-black w-3 h-3 rounded-full block relative before:absolute before:content-[''] before:w-4 before:h-1 before:bg-x-black before:right-0 before:top-1/2 before:-translate-y-1/2 before:rounded-full rtl:before:left-0 rtl:before:right-auto"></span>
        <?php endif; ?>
    </div>
    <?php if($base->Categories->count()): ?>
        <ul id="category_<?php echo e($base->id); ?>" class="x-category hidden relative px-2">
            <?php $__currentLoopData = $base->Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('shared.guest.items', [
                    'base' => $category,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH P:\php\store_management_system\resources\views/shared/guest/items.blade.php ENDPATH**/ ?>